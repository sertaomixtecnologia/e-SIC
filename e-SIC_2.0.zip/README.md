# e-SIC Livre 2.0

Original disponivel em https://softwarepublico.gov.br/gitlab/e-sic-livre/e-sic-livre/commits/master
Informações do software original disponivel em https://softwarepublico.gov.br/social/e-sic-livre

# Diferenciais 
No momento trata-se de uma versão de adaptação e compatibilidade com versões do PHP >= 7
Não houveram alterações incrementais

# Instalação
Após depositar todo o conteúdo no servidor, acesse pela barra de endereço do navegador de sua preferência a pasta instalar (ex. www.seudominio.com.br/instalar) e preencha o formulário de acordo com as indicações de sua hospedagem ou as configurações definidas para os serviços de banco de dados e email.
