<?php
/**********************************************************************************
 Sistema e-SIC Livre: sistema de acesso a informação baseado na lei de acesso.
 
 Copyright (C) 2014 Prefeitura Municipal do Natal
 
 Este programa é software livre; você pode redistribuí-lo e/ou
 modificá-lo sob os termos da Licença GPL2.
***********************************************************************************/

require_once("../inc/security.php");
include("../inc/topo.php"); 
?>

    <div id="pag_titulo">
		<h1>FALE CONOSCO</h1>   
   	</div>
	
	<div id="controle"> 
	
	<div id="ouvidoria">
	<p><br><b>Ouvidoria<br>
	<span>Faça sua Den&uacute;ncia, Elogio ou Reclama&ccedil;&atilde;o atrav&eacute;s dos seguintes contatos:</span></b><br>
	<i>e-mail : ouvidoria@dominio<br>
	Telefone : 3232-6748 e 3232-6389<br>
	Twitter: https://twitter.com/</i><br></p>
	</div>
	</div>
	
<?php include("../inc/rodape.php"); ?>