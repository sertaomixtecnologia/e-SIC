<?php
/**********************************************************************************
 Sistema e-SIC Livre: sistema de acesso a informação baseado na lei de acesso.
 
 Copyright (C) 2014 Prefeitura Municipal do Natal
 
 Este programa é software livre; você pode redistribuí-lo e/ou
 modificá-lo sob os termos da Licença GPL2.
***********************************************************************************/

    require_once("../inc/security.php");
    isauth();
    /*session_start();
    if(! isset($_SESSION["logado"]))
	{
		header("Location: ../index.php");
		die();
	}*/
?>
