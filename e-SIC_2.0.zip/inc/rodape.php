<?php
/**********************************************************************************
 Sistema e-SIC Livre: sistema de acesso a informação baseado na lei de acesso.
 
 Copyright (C) 2014 Prefeitura Municipal do Natal
 
 Este programa é software livre; você pode redistribuí-lo e/ou
 modificá-lo sob os termos da Licença GPL2.
***********************************************************************************/
?>

				<!--/div-->
				
					<div id="rodape">
					
						<div id="rodapetexto1">
							SEMPLA desenvolvimento. Seguimos as seguintes recomendações de projeto:
						</div>
                                       
						<div id="iconesw3c" >
							<img class="w3c" src="../css/img/w3c_css.png" alt="W3C"/>
							<img class="w3c" src="../css/img/w3c_xhtml.png" alt="W3C"/>
							<img class="w3c" src="../css/img/w3c_aa.png" alt="W3C"/>

						</div>
						<div id="rodapetexto2">
							Produzido com tecnologias livres, socialmente justas para um desenvolvimento sustentável.
						</div>
					</div>
				</div>
			</div>
	  
	</body>
</html>
